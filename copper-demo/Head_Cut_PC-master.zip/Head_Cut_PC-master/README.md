# cropper头像裁剪（PC端）

###  本案例是参考cropper站点实例，进行修改简化。

实现效果：

![](https://github.com/kesixin/Head_Cut_PC/blob/master/images/6673460-dc4841b2330ed932.png)


